import { useState, useRef, useCallback } from "react";
import Head from "next/head";

const SYSTEM_PROMPT = `You are a brutally honest, clinically objective facial aesthetics analyst trained in orthognathic surgery assessment, facial anthropometry, and aesthetic medicine. You rate faces using the PSL ranking system used in facial aesthetics communities.

Your analysis must be:
- Completely honest, unsparing, and clinically precise
- Based on objective measurements and proportions, not feelings
- Focused on bone structure, soft tissue, symmetry, and proportionality
- Free of sugarcoating — you give the truth as a professional analyst

THE PSL RANKING TIERS (from worst to best):

Sub5 — Extreme deformity and severe deficiencies. Severe facial asymmetry, missing bone mass, extreme dysmorphia. Very rare and severe.

LLTN (Low Low Tier Normal) — Noticeably ugly with clear deficiencies: bad proportions, lack of bone mass, poor facial structure overall. Not as severe as Sub5 but significantly unattractive.

MLTN (Mid Low Tier Normal) — Slightly below the low end of average. Common deficiencies: flat maxilla projection, disproportionate features, bloated/puffy face, excess facial fat, recessed chin, weak jaw.

HLTN (High Low Tier Normal) — Lower-end average. Similar issues to MLTN but with fewer or less extreme flaws. Slight deviations from average. Not quite average but close.

LMTN (Low Mid Tier Normal) — Average looking. Normal minor flaws (falios), nothing major. Not ugly, not attractive. Blends into a crowd. No standout attractive features.

MMTN (Mid Mid Tier Normal) — Slightly above average. Fewer flaws than LMTN, slight features that add a touch of attractiveness but nothing remarkable.

HMTN (High Mid Tier Normal) — Noticeably good-looking. Clearly fewer flaws, multiple attractive features that are noticeable. Above average in an obvious way.

LHTN (Low High Tier Normal) — Very good looking. Almost no flaws. Good facial harmony in proportions and features. Not supermodel-tier but very noticeably attractive.

MHTN (Mid High Tier Normal) — Basically LHTN but with noticeably better harmony and features. Very attractive.

HHTN (High High Tier Normal) — Entry-level model status. No visible flaws, excellent proportions and harmony, better than MHTN. Almost Chad Lite but not quite there.

CL (Chad Lite) — Basically perfect facially. Has achieved full genetic potential. Zero flaws. Very noticeable attraction. Rare. Still below a true Chad in raw genetic quality.

Chad — Beyond perfect symmetry, harmony, proportions, and features. Genetically elite. Extremely rare.

True Adam — The absolute pinnacle of human facial beauty. The mathematically and aesthetically perfect face. Almost mythical in rarity.

---

YOUR ANALYSIS FORMAT:

**TIER RATING: [TIER NAME]**
**SCORE: X/10**

**FACIAL THIRDS ANALYSIS:**
[Assess upper, mid, lower third proportions — are they equal? Which is dominant or deficient?]

**BONE STRUCTURE & PROJECTION:**
[Assess maxilla, zygomatic arches, mandible, orbital bones, forehead. Comment on forward growth vs recession.]

**FACIAL SYMMETRY:**
[Assess vertical and horizontal symmetry. Note any deviations, tilts, or asymmetries.]

**FEATURES ASSESSMENT:**
[Eyes (orbital rim, canthal tilt, intercanthal distance, hooding), Nose (bridge height, tip projection, width, nasofacial angle), Lips (vermillion border, Cupid's bow, philtrum length, lip ratio), Jawline (gonial angle, definition, width), Chin (projection, height, shape)]

**SKIN & SOFT TISSUE:**
[Bichectomy candidacy, submental fat, skin texture, aging signs if applicable]

**NOTABLE STRENGTHS:**
[List specific features that elevate the rating]

**NOTABLE FLAWS / FALIOS:**
[List specific flaws that lower the rating. Be precise and clinical.]

**IMPROVEMENT POTENTIAL:**
[What procedures or changes (orthodontics, surgery, grooming, body fat reduction) could realistically improve the rating and by how much?]

**FINAL VERDICT:**
[A concise 2-3 sentence summary of the overall face and why this tier was assigned]

Be specific, clinical, and honest. Do not be cruel for cruelty's sake, but do not sugarcoat. The goal is an accurate, professional assessment.`;

const TIERS = [
  { id: "sub5",  label: "Sub5",      color: "#7f1d1d", desc: "Extreme deformity" },
  { id: "lltn",  label: "LLTN",      color: "#991b1b", desc: "Noticeably ugly" },
  { id: "mltn",  label: "MLTN",      color: "#b45309", desc: "Below low average" },
  { id: "hltn",  label: "HLTN",      color: "#92400e", desc: "Low average" },
  { id: "lmtn",  label: "LMTN",      color: "#78716c", desc: "Average" },
  { id: "mmtn",  label: "MMTN",      color: "#4b5563", desc: "Slightly above avg" },
  { id: "hmtn",  label: "HMTN",      color: "#1d4ed8", desc: "Noticeably good" },
  { id: "lhtn",  label: "LHTN",      color: "#1e40af", desc: "Very good looking" },
  { id: "mhtn",  label: "MHTN",      color: "#6d28d9", desc: "Exceptional" },
  { id: "hhtn",  label: "HHTN",      color: "#7c3aed", desc: "Model entry" },
  { id: "cl",    label: "Chad Lite", color: "#c026d3", desc: "Near perfect" },
  { id: "chad",  label: "Chad",      color: "#db2777", desc: "Genetically elite" },
  { id: "adam",  label: "True Adam", color: "#f59e0b", desc: "Peak human beauty" },
];

function formatAnalysis(text) {
  if (!text) return null;
  return text.split("\n").map((line, i) => {
    if (line.startsWith("**") && line.endsWith("**")) {
      return (
        <div key={i} style={{ color: "#f59e0b", fontWeight: 700, marginTop: 18, fontFamily: "monospace", letterSpacing: 1 }}>
          {line.replace(/\*\*/g, "")}
        </div>
      );
    }
    if (line.includes(":**")) {
      const idx = line.indexOf(":**");
      const bold = line.slice(0, idx).replace(/\*\*/g, "");
      const rest = line.slice(idx + 3);
      return (
        <div key={i} style={{ marginTop: 10 }}>
          <span style={{ color: "#e2e8f0", fontWeight: 700, fontFamily: "monospace" }}>{bold}:</span>
          <span style={{ color: "#94a3b8" }}>{rest}</span>
        </div>
      );
    }
    if (line.trim() === "") return <div key={i} style={{ height: 6 }} />;
    return <div key={i} style={{ color: "#94a3b8", lineHeight: 1.8, marginTop: 2 }}>{line}</div>;
  });
}

export default function Home() {
  const [image, setImage]       = useState(null);
  const [imageData, setImageData] = useState(null);
  const [analysis, setAnalysis] = useState("");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [detectedTier, setDetectedTier] = useState(null);
  const fileRef = useRef();

  const handleFile = useCallback((file) => {
    if (!file || !file.type.startsWith("image/")) {
      setError("Please upload a valid image file.");
      return;
    }
    setError(""); setAnalysis(""); setDetectedTier(null);
    setImage(URL.createObjectURL(file));
    const reader = new FileReader();
    reader.onload = (e) => {
      setImageData({ base64: e.target.result.split(",")[1], mediaType: file.type });
    };
    reader.readAsDataURL(file);
  }, []);

  const analyze = async () => {
    if (!imageData) return;
    setLoading(true); setAnalysis(""); setError(""); setDetectedTier(null);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1800,
          system: SYSTEM_PROMPT,
          messages: [{
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: imageData.mediaType, data: imageData.base64 } },
              { type: "text", text: "Analyze this face using the full PSL rating system. Be completely honest and clinically precise. Assess all facial features, proportions, symmetry, bone structure, and soft tissue. Assign the correct tier and score." }
            ]
          }]
        })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error);
      const text = data.content?.map(b => b.text || "").join("\n") || "";
      setAnalysis(text);

      const u = text.toUpperCase();
      let found = null;
      if (u.includes("TRUE ADAM"))                       found = "adam";
      else if (u.includes("CHAD LITE") || /\bCL\b/.test(u)) found = "cl";
      else if (/\bCHAD\b/.test(u))                       found = "chad";
      else if (u.includes("HHTN")) found = "hhtn";
      else if (u.includes("MHTN")) found = "mhtn";
      else if (u.includes("LHTN")) found = "lhtn";
      else if (u.includes("HMTN")) found = "hmtn";
      else if (u.includes("MMTN")) found = "mmtn";
      else if (u.includes("LMTN")) found = "lmtn";
      else if (u.includes("HLTN")) found = "hltn";
      else if (u.includes("MLTN")) found = "mltn";
      else if (u.includes("LLTN")) found = "lltn";
      else if (u.includes("SUB5") || u.includes("SUB-5")) found = "sub5";
      setDetectedTier(found);
    } catch (err) {
      setError("Analysis failed: " + err.message);
    }
    setLoading(false);
  };

  const tierData = detectedTier ? TIERS.find(t => t.id === detectedTier) : null;

  return (
    <>
      <Head>
        <title>PSL Rating Engine</title>
        <meta name="description" content="Clinical facial aesthetics analysis using the PSL ranking framework" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div style={{ minHeight: "100vh", background: "#0a0a0f", color: "#e2e8f0", fontFamily: "'Georgia', serif", padding: "32px 16px" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontSize: 11, letterSpacing: 6, color: "#475569", fontFamily: "monospace", marginBottom: 8 }}>
            FACIAL AESTHETICS ANALYSIS SYSTEM
          </div>
          <h1 style={{
            fontSize: "clamp(28px, 5vw, 48px)", fontWeight: 900, margin: 0, letterSpacing: -1,
            background: "linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent"
          }}>
            PSL RATING ENGINE
          </h1>
          <div style={{ height: 1, background: "linear-gradient(90deg, transparent, #334155, transparent)", margin: "16px auto", maxWidth: 400 }} />
          <p style={{ color: "#475569", fontSize: 13, maxWidth: 480, margin: "0 auto", lineHeight: 1.6 }}>
            Clinical-grade facial analysis using the PSL ranking framework. Honest. Objective. Unsparing.
          </p>
        </div>

        {/* Tier Scale */}
        <div style={{ maxWidth: 760, margin: "0 auto 36px", display: "flex", gap: 4, flexWrap: "wrap", justifyContent: "center" }}>
          {TIERS.map(t => (
            <div key={t.id} style={{
              padding: "4px 10px", borderRadius: 4,
              background: detectedTier === t.id ? t.color : "rgba(255,255,255,0.03)",
              border: `1px solid ${detectedTier === t.id ? t.color : "#1e293b"}`,
              fontSize: 11, fontWeight: 700,
              color: detectedTier === t.id ? "#fff" : "#475569",
              fontFamily: "monospace", letterSpacing: 0.5, transition: "all 0.3s"
            }}>
              {t.label}
            </div>
          ))}
        </div>

        {/* Main Grid */}
        <div style={{
          maxWidth: 760, margin: "0 auto",
          display: "grid",
          gridTemplateColumns: image ? "1fr 1fr" : "1fr",
          gap: 24
        }}>

          {/* Upload */}
          <div>
            <div
              onClick={() => fileRef.current?.click()}
              onDrop={e => { e.preventDefault(); handleFile(e.dataTransfer.files[0]); }}
              onDragOver={e => e.preventDefault()}
              style={{
                border: "1px dashed #1e293b", borderRadius: 8,
                padding: image ? 0 : "56px 24px",
                textAlign: "center", cursor: "pointer",
                background: "rgba(255,255,255,0.02)",
                overflow: "hidden", minHeight: image ? 280 : "auto"
              }}
            >
              {image
                ? <img src={image} alt="subject" style={{ width: "100%", display: "block", maxHeight: 420, objectFit: "cover" }} />
                : <>
                    <div style={{ fontSize: 40, opacity: 0.2, marginBottom: 12 }}>◉</div>
                    <div style={{ color: "#475569", fontSize: 14 }}>Drop image here or click to upload</div>
                    <div style={{ color: "#334155", fontSize: 12, marginTop: 8 }}>Front-facing photos work best</div>
                  </>
              }
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={e => handleFile(e.target.files[0])} />

            {image && (
              <button onClick={analyze} disabled={loading} style={{
                width: "100%", marginTop: 12, padding: 14,
                background: loading ? "#1e293b" : "linear-gradient(135deg, #1e3a8a, #1d4ed8)",
                color: loading ? "#475569" : "#e2e8f0",
                border: "none", borderRadius: 6, fontSize: 13, fontWeight: 700,
                letterSpacing: 2, fontFamily: "monospace", cursor: loading ? "not-allowed" : "pointer"
              }}>
                {loading ? "ANALYZING..." : "ANALYZE FACE"}
              </button>
            )}

            {image && (
              <button onClick={() => { setImage(null); setImageData(null); setAnalysis(""); setDetectedTier(null); setError(""); }}
                style={{
                  width: "100%", marginTop: 8, padding: 10,
                  background: "transparent", color: "#334155",
                  border: "1px solid #1e293b", borderRadius: 6, fontSize: 12,
                  fontFamily: "monospace", cursor: "pointer"
                }}>
                CLEAR
              </button>
            )}

            {tierData && (
              <div style={{
                marginTop: 12, padding: 16,
                background: `${tierData.color}18`,
                border: `1px solid ${tierData.color}50`,
                borderRadius: 6, textAlign: "center"
              }}>
                <div style={{ fontSize: 10, color: "#64748b", letterSpacing: 3, fontFamily: "monospace" }}>ASSIGNED TIER</div>
                <div style={{ fontSize: 30, fontWeight: 900, color: tierData.color, fontFamily: "monospace", marginTop: 4 }}>{tierData.label}</div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{tierData.desc}</div>
              </div>
            )}

            {error && (
              <div style={{ marginTop: 12, padding: 12, background: "#7f1d1d20", border: "1px solid #7f1d1d", borderRadius: 6, color: "#fca5a5", fontSize: 13 }}>
                {error}
              </div>
            )}
          </div>

          {/* Analysis */}
          {(analysis || loading) && (
            <div style={{
              background: "rgba(255,255,255,0.02)", border: "1px solid #1e293b",
              borderRadius: 8, padding: 20, maxHeight: 600, overflowY: "auto"
            }}>
              <div style={{ fontSize: 10, letterSpacing: 4, color: "#334155", fontFamily: "monospace", marginBottom: 16 }}>
                ANALYSIS REPORT
              </div>
              {loading && !analysis
                ? <div style={{ color: "#334155", fontSize: 13, fontFamily: "monospace" }}>Processing facial geometry...</div>
                : <div style={{ fontSize: 13, lineHeight: 1.8 }}>{formatAnalysis(analysis)}</div>
              }
            </div>
          )}
        </div>

        <div style={{ textAlign: "center", marginTop: 56, color: "#1e293b", fontSize: 11, fontFamily: "monospace", letterSpacing: 1 }}>
          FOR EDUCATIONAL & ANALYTICAL PURPOSES ONLY · PSL FRAMEWORK
        </div>
      </div>
    </>
  );
}
