# PSL Rating Engine 🔍

موقع تحليل ملامح الوجه باستخدام نظام PSL Ranking.

---

## 🚀 طريقة التشغيل المحلي

### 1. تثبيت المتطلبات
```bash
npm install
```

### 2. إعداد مفتاح API
```bash
# انسخ الملف
cp .env.local.example .env.local

# افتح .env.local وضع مفتاحك من https://console.anthropic.com
ANTHROPIC_API_KEY=sk-ant-...
```

### 3. تشغيل الموقع
```bash
npm run dev
```
ثم افتح المتصفح على: **http://localhost:3000**

---

## ☁️ نشر على Vercel (مجاني)

### الطريقة السريعة:
1. ارفع المشروع على [GitHub](https://github.com)
2. اذهب إلى [vercel.com](https://vercel.com) وسجّل دخول
3. اضغط **"New Project"** واختر الـ repo
4. في **Environment Variables** أضف:
   - `ANTHROPIC_API_KEY` = مفتاحك
5. اضغط **Deploy** ✅

سيعطيك Vercel رابطاً مثل: `https://psl-rater.vercel.app`

---

## 📁 هيكل المشروع
```
psl-rater/
├── pages/
│   ├── api/
│   │   └── analyze.js     ← API Route (السيرفر - آمن)
│   ├── _app.js
│   └── index.js           ← الصفحة الرئيسية
├── styles/
│   └── globals.css
├── .env.local             ← مفتاح API (لا ترفعه على GitHub!)
├── .gitignore
├── next.config.js
└── package.json
```
